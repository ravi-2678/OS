#include<bits/stdc++.h>
using namespace std;
int main(){
	int time=0;
	
	int framesize;
	cin>>framesize;
	vector<pair<int,int>>v(framesize);
	int n;
	cin>>n;
	int pf=0,hit=0;
	for(int i=0;i<n;i++){
		int x;
		cin>>x;
		time++;
		if(v.size()<framesize){
			v[i].first=x;
			v[i].second=time;
			pf++;
			continue;
			
		}
		bool flag=false;
		for(int j=0;j<v.size();j++){
			if(v[j].first==x){
			hit++;
				v[j].second=time;
				flag=true;
				break;
			}
		}
		if(!flag){
		pf++;
			int mini=INT_MAX,index=0,j;
			for(j=0;j<v.size();j++){
				if(v[j].second<mini){
					mini=v[j].second;
					index=j;
				}
				
			}
			v[index].first=x;
			v[index].second=time;
			
		}
	}
	cout<<"page fault:"<<pf<<endl;
	cout<<"hits:"<<hit<<endl;
	
}
